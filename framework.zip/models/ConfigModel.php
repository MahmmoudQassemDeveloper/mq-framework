<?php
// مودل خاص بالاتصال بقاعدة البيانات والتعامل مع الدوال الخاصه بالمدرسين والطلاب
class ConfigModel extends ConfigController
{
    function __construct(){
        // cdoe...
    }
}