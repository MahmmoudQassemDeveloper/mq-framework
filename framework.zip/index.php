<?php
	try {
		session_start();
		date_default_timezone_set('UTC');
		$dir = __DIR__;
		$dir = explode('\\', trim($dir ,3));
		$dir = $dir[0];
		define('PUBLIC_DIR', '../'.$dir);
		define('HOMEPAGE', PUBLIC_DIR.'/home');
		require_once 'config.php';
		require_once 'controllers/AbstructController.php';
		$abstruct = new AbstructController();
		$abstruct->getRoute();
		extract($_SESSION);
	} catch (PDOException $e) {
			echo $e->getMessage();
	}
?>