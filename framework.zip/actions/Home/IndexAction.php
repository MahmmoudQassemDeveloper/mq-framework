<div class="swiper-container">
    <div class="swiper-slide">
        <span>Mahmoud Qassem Framework</span>
        <a href="#">Get Started</a>
        <a style='margin-top:270px;width:auto;'>Mahmoud Qassem Framework v1.0.0</a>
    </div>
</div>