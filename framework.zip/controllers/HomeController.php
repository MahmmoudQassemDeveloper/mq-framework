<?php
class HomeController extends AbstructController
{
    public $modal;

    function __construct()
    {
        
    }

    public function Index()
    {
        $this->render("Home", $this->data);
    }
}
?>