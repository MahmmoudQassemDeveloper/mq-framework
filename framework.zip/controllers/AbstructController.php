<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

class AbstructController extends ConfigController
{
	private $controller_name = 'home';
	private $action_name = 'index';
	private $action_path = '';
	private $model = null;
	public $data = array();
	public $settings = null;
	function __construct(){
		$this->controller_name = isset($_GET['controller']) ? $_GET['controller'] : 'Home';
		$this->action_name = isset($_GET['action']) ? $_GET['action'] : 'Index';
		$this->connection();
        if(!defined('ROOT')){
            define('ROOT', $_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['HTTP_HOST'].str_replace('/index.php', '', $_SERVER['PHP_SELF']));
        }
        if(!defined('REQUEST_POST')){
			define('REQUEST_POST', $_POST);
		}
		if(!defined('REQUEST_GET')){
			define('REQUEST_GET', $_GET);
		}

	}
	public function getRoute()
	{
		$this->controller = 'controllers/'.$this->controller_name.'Controller.php';	
		define('CONTROLLER_NAME', strtolower($this->controller_name));
		define('ACTION_NAME', strtolower($this->action_name));
		if(file_exists($this->controller))
		{
			require_once $this->controller;
			$this->action_path = 'actions/'.$this->controller_name.'/'.$this->action_name.'Action.php';
			$this->controller_name = $this->controller_name.'Controller';
			define('CONTROLLER_NAME_FOR_MENU', str_replace("Controller","",$this->controller_name));
			define('ACTION_NAME_FOR_MENU', str_replace("Action","",$this->action_name));
			$this->controller = new $this->controller_name();
			if(method_exists($this->controller, $this->action_name) && file_exists($this->action_path))
			{
				$this->SetActionPath($this->action_path);
				$an = $this->action_name;
				$this->controller->$an();
			}
			else if(method_exists($this->controller, $this->action_name)){
				$an = $this->action_name;
				$this->controller->$an();
			}
			else{
				echo "Can't found the page...";
			}
		}
		else{
			echo "Can't found the page...";
		}
	}
	private function SetActionPath($action_path=null)
	{
		unset($_SESSION['action_path']);
		$_SESSION['action_path'] = $action_path;
	}
	private function GetActionPath()
	{
		return $_SESSION['action_path'];
	}
	public function LoadModel($ModelName = null)
	{
		$modelpath = str_replace(basename(__DIR__), '', __DIR__);
		require_once $modelpath.'/models/'.$ModelName.'Model.php';
		$model = ucfirst($ModelName)."Model";
		$modelObject = new $model();
		return $modelObject;
	}
	public function render($page_title = null, $data = null){
		define('STATICPAGE_TITLE', "SiteName");
		define("PAGETITLE", $page_title);
		require_once 'template/header.php';
		require_once $this->GetActionPath();
		require_once 'template/footer.php';
		return $data;
	}
    public function Json($key, $msg, $data)
    {
        $jar = array(
            "key"=>$key,
            "msg"=>$msg,
            "data"=>$data == null ? [] : $data
        );
        print(json_encode($jar));
    }
	public function LoadReport($ReportName = null, $vars = null)
	{
		$modelpath = __DIR__;
		$modelpath = str_replace("controllers","",$modelpath);
		$qu =  file_get_contents($modelpath.'/reports/'.$ReportName.'.html');
		if($vars != null){
			foreach(array_keys($vars) as $key)
			{
				$qu = str_replace($key, $vars[$key], $qu);
			}
		}
		return $qu;
	}
	public function LoadProcedure($ProcedureName = null, $vars, $action = false, $filter = null)
	{
        $modelpath = __DIR__;
        $qu =  file_get_contents('procedures/'.$ProcedureName.'.sql');
        if($vars != null){
            foreach(array_keys($vars) as $key)
            {
                if(is_numeric($vars[$key]) || is_float($vars[$key])){
                    if(null == $vars[$key]){
                        $qu = str_replace($key, 0, $qu);
                    }else{
                        $qu = str_replace($key, $vars[$key], $qu);
                    }
                }else if(is_string($vars[$key])){
                    if(null == $vars[$key]){
                        $qu = str_replace($key, 'null', $qu);
                    }else{
                        $qu = str_replace($key, "'".$vars[$key]."'", $qu);
                    }
                }
            }
		}

		// extract where
		$havWhere = false;
		$i = strlen($qu) - 1;
		while($i > 0){
			if(substr(strtolower($qu) , $i, 5) === 'where'){
				$havWhere = true;
			}
			if(substr(strtolower($qu) , $i, 4) === 'from'){
				break;
			}
			$i-=1;
		}

		$filter_string = '';
		$n=false;
		$j=0;
		if(!empty($filter)){
			$filter_string = $havWhere ? ' AND ' : ' WHERE ';
			foreach($filter as $fltr){
				if(is_string($fltr[0]['col_value'])){
					$fltr[0]['col_value'] = "'".$fltr[0]['col_value']."'";
				}
				if(false === $n){
					$filter_string .= $fltr[0]['col_name'].'='.$fltr[0]['col_value'];
					$n = true;
				}else{
					$filter_string .= ' AND '. $fltr[0]['col_name'].'='.$fltr[0]['col_value'];
				}
				$j+=1;
			}
		}

		$orderBy = '';
		$orderExp = explode('order by', strtolower($qu));
		if(count($orderExp) > 1){
			$orderBy = 'order by' . $orderExp[count($orderExp)-1];
			$qu = str_replace(strtolower($orderBy),'',  strtolower($qu));
		}

		if(!empty($filter_string)){
			$qu .= ' '.$filter_string;
		}
		if(!empty($orderBy)){
			$qu .= ' '.$orderBy;
		}

        if(!$action){
            $coon = $this->connection();
            $result = $coon->prepare($qu);
            $result->execute();
            $result= $result->fetchAll();
            return $result;
        }else{
            $coon = $this->connection();
            $result = $coon->exec($qu);
            return $result;
        }
	}
	public function GetArrayString($obj){
	    foreach (array_keys($obj) as $key){
	        if(!is_string($key)){
                unset($obj[$key]);
            }
        }
	    return $obj;
    }
    public function RedirectToAction($controller, $action= null){
        if($action == null){
            header('location:'.ROOT.'/'.$controller);
        }else{
            header('location:'.ROOT.'/'.$controller.'/'.$action);
        }
	}
	public function ServerType($name)
	{
		if(strtolower($_SERVER['REQUEST_METHOD']) === strtolower($name)){
			return true;
		}
		$this->RedirectToAction('Home');
	}
	public function SendEmail($EmailObject)
	{
		if($EmailObject === null) return;
		// Import PHPMailer classes into the global namespace
		require 'phpmailler/vendor/phpmailer/phpmailer/src/Exception.php';
		require 'phpmailler/vendor/phpmailer/phpmailer/src/PHPMailer.php';
		require 'phpmailler/vendor/phpmailer/phpmailer/src/SMTP.php';
		
		// Load Composer's autoloader
		
		require 'phpmailler/vendor/autoload.php';

		// Instantiation and passing `true` enables exceptions
		$mail = new PHPMailer(true);

		try {
			//Server settings
			$mail->SMTPDebug = self::SMTPDebug;                    // Enable verbose debug output
			$mail->isSMTP();                                            // Send using SMTP
			$mail->Host       = self::Host;                   // Set the SMTP server to send through
			$mail->SMTPAuth   = true;                                   // Enable SMTP authentication
			$mail->Username   = self::Username;               // SMTP username
			$mail->Password   = self::Password;               // SMTP password
			$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
			$mail->Port       = self::Port; // 587             // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
			$mail->CharSet = 'UTF-8';
			//Recipients
			$mail->setFrom($EmailObject['FROM'], $EmailObject['SENDER']);
			$mail->addAddress($EmailObject['TO'], $EmailObject['RECIPIENT']);     // Add a recipient

			// Content
			$mail->isHTML(boolval($EmailObject['ISHTML']));                       // Set email format to HTML
			$mail->Subject = $EmailObject['SUBJECT'];
			$mail->Body    = $EmailObject['BODY'];
			$mail->AltBody = $EmailObject['ALTBODY'];

			$mail->send();
		} catch (Exception $e) {
			return false;
		}
	}
}