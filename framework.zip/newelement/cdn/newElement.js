function newElement(parent ,elementName, attrs, functions) {
  if(undefined !== elementName || elementName != null)
  {
    var el = document.createElement(elementName);
    let d = {
      child : {
        add : function(child){
          el.appendChild(child);
        },
        remove : function(child){
          el.removeChild(child);
        }
      },
      html : function(html){
        if(undefined !== html && null !== html){
          el.innerHTML = html;
        }else{
          return el.innerHTML;
        }
      },
      text : function(text){
        if(undefined !== text && null !== text){
          el.innerText = text;
        }else{
          return el.innerText;
        }
      },
      attr : {
        add : function(attrname, attrvalue){
          el.setAttribute(attrname, attrvalue);
        },
        remove : function(attrname){
          el.removeAttribute(attrname);
        },
        has : function(attrname){
          if(null !== el.getAttribute(attrname)){
            return true;
          }else{
            return false;
          }
        }
      },
      classList : {
        add : function(classname){
          el.classList.add(classname);
        },
        remove : function(classname){
          el.classList.remove(classname);
        },
        toggle : function(classname){
          el.classList.toggle(classname);
        },
        has : function(classname){
          let having = false;
          el.classList.forEach((className, i) => {
            if(className == classname){
              having = true;
            }
          });
          return having;
        }
      },
      css : {
        add : function(propName, propValue){
          if(typeof propName === 'object'){
            let cssCode = '';
            propName.forEach(element =>{
                if(cssCode === ''){
                  cssCode = element;
                }else{
                  cssCode = cssCode + ';' + element;
                }
            });
            el.setAttribute('style', cssCode);
          }else{
            el.style[propName.toString().toLowerCase()] = propValue;
          }
        },
        remove : function(propName){
          let i = 0;
          let cssText = el.style.cssText.toString().split(';');
          let cssResult = '';
          cssText.forEach(element => {
            let elm = element.toString().replace(' ', '');
            if(elm.toString().substring(0, propName.toString().toLowerCase().length).toLowerCase() !== propName.toLowerCase()){
              if(cssResult === ''){
                cssResult = element;
              }else{
                cssResult = cssResult + ';' + element;
              }
            }
          });
          if(cssResult.substring(cssResult.length, cssResult.length - 1) == ','){
            cssResult = cssResult.substring(0, cssResult.length - 1);
          }
          el.setAttribute('style', cssResult);
        },
        has : function(propName){
          let i = 0;
          let cssText = el.style.cssText.toString().split(';');
          let hav = false;
          cssText.forEach(element => {
            if(!hav){
              let elm = element.toString().replace(' ', '');
              if(elm.toString().substring(0, propName.toString().toLowerCase().length).toLowerCase() === propName.toLowerCase()){
                hav = true;
              }
            }
          });
          return hav;
        }
      },
      event : function(name, method){
        el.addEventListener(name, function(e){
          new method(this, e);
        })
      },
      each : function(fun){
        let i = 0;
        let selectors = el.childNodes;
        for(i = 0; i < selectors.length; i++){
          new fun(makeElement(selectors[i]), i);
        }
      },
      e : el,
      childs : el.childNodes
    };
    if(undefined !== parent && null !== parent){
      parent.appendChild(el);
    }
    return d;
  }
  return undefined;
}
function makeElement(element){
  if(undefined !== element || element != null)
  {
    var el = element;
    let d = {
      child : {
        add : function(child){
          el.appendChild(child);
        },
        remove : function(child){
          el.removeChild(child);
        }
      },
      html : function(html){
        el.innerHTML = html;
      },
      text : function(text){
        el.innerText = text;
      },
      attr : {
        add : function(attrname, attrvalue){
          el.setAttribute(attrname, attrvalue);
        },
        remove : function(attrname){
          el.removeAttribute(attrname);
        }
      },
      classList : {
        add : function(classname){
          el.classList.add(classname);
        },
        remove : function(classname){
          el.classList.remove(classname);
        },
        toggle : function(classname){
          el.classList.toggle(classname);
        },
        has : function(classname){
          let having = false;
          el.classList.forEach((className, i) => {
            if(className == classname){
              having = true;
            }
          });
          return having;
        }
      },
      css : {
        add : function(propName, propValue){
          if(typeof propName === 'object'){
            let cssCode = '';
            propName.forEach(element =>{
                if(cssCode === ''){
                  cssCode = element;
                }else{
                  cssCode = cssCode + ';' + element;
                }
            });
            el.setAttribute('style', cssCode);
          }else{
            el.style[propName.toString().toLowerCase()] = propValue;
          }
        },
        remove : function(propName){
          let i = 0;
          let cssText = el.style.cssText.toString().split(';');
          let cssResult = '';
          cssText.forEach(element => {
            let elm = element.toString().replace(' ', '');
            if(elm.toString().substring(0, propName.toString().toLowerCase().length).toLowerCase() !== propName.toLowerCase()){
              if(cssResult === ''){
                cssResult = element;
              }else{
                cssResult = cssResult + ';' + element;
              }
            }
          });
          if(cssResult.substring(cssResult.length, cssResult.length - 1) == ','){
            cssResult = cssResult.substring(0, cssResult.length - 1);
          }
          el.setAttribute('style', cssResult);
        },
        has : function(propName){
          let i = 0;
          let cssText = el.style.cssText.toString().split(';');
          let hav = false;
          cssText.forEach(element => {
            if(!hav){
              let elm = element.toString().replace(' ', '');
              if(elm.toString().substring(0, propName.toString().toLowerCase().length).toLowerCase() === propName.toLowerCase()){
                hav = true;
              }
            }
          });
          return hav;
        }
      },
      event : function(name, method){
        el.addEventListener(name, function(e){
          new method(this, e);
        })
      },
      each : function(fun){
        let i = 0;
        let selectors = el.childNodes;
        for(i = 0; i < selectors.length; i++){
          new fun(selectors[i], i);
        }
      },
      e : el,
      childs : el.childNodes
    };
    return d;
  }
  return undefined;
}