window.onload = function(){
    let app = getElement('#app');
    let divBottom = newElement(app, 'div');
    divBottom.classList.add('menu');
    let ul = newElement(divBottom.e, 'ul');
    var list = [
        {
            icon : 'fa-bars'
        },
        {
            icon : 'fa-image',
            event : function(obj){
                let imgDiv = newElement(obj, 'div');
                imgDiv.classList.add('imgDiv');
                let img = newElement(imgDiv.e, 'img');
                let link = window.prompt('ادخل رابط الصورة');
                if(link){
                    img.attr.add('src', link);
                    img.attr.add('resize', true);
                    newElement(obj, 'br');
                }
            },
            text : 'صورة'
        },
        {
            icon : 'fa-camera',
            event : function(obj){
                let frameDiv = newElement(obj, 'div');
                frameDiv.classList.add('frameDiv');
                let iframe = newElement(frameDiv.e, 'iframe');
                let link = window.prompt('ادخل رابط الفيديو');
                if(link){
                    let eq = link.indexOf('=') + 1;
                    link = link.substring(eq);
                    iframe.attr.add('src', 'https://www.youtube.com/embed/'+link);
                    iframe.attr.add('resize', true);
                    newElement(obj, 'br');
                }
            },
            text : 'فيديو'
        },
        {
            icon : 'fa-font',
            event : function(obj){
                let text = newElement(obj, 'h2');
                text.classList.add('text');
                let t = window.prompt('ادخل النص');
                if(t){
                    text.text(t);
                }
            },
            text : 'نص جديد'
        },
        {
            icon : 'fa-link',
            event : function(obj){
                let a = newElement(obj, 'a');
                let atext = prompt('مسمى الرابط');
                if(null !== atext){
                    let link = window.prompt('ادخل رابط');
                    if(null !== link){
                        a.text(atext);
                        a.attr.add('href', link);
                        a.attr.add('target', '_blank');
                        newElement(obj, 'br');
                    }
                }
            },
            text : 'رابط'
        },
        {
            icon : 'fa-star',
            event : function(obj, bg)
            {
                let bgUrl = prompt('ادخل رابط الخلفية');
                if(null !== bgUrl){
                    bg.css.add([
                        'background-image:url(' + bgUrl + ')'
                    ]);
                }
            },
            text : 'خلفية الصفحة'
        },
        {
            icon : 'fa-eye',
            event : function(obj){
                if(tools.attr.has('contenteditable')){
                    tools.attr.remove('contenteditable');
                }else{
                    tools.attr.add('contenteditable', true);
                }
            },
            text : 'معاينة'
        }
    ];
    list.forEach(function(element, e){
        let li = newElement(ul.e, 'li');
        let a = newElement(li.e, 'a');
        let fa = newElement(a.e, 'i');
        let sp = newElement(a.e, 'span');
        fa.classList.add('fa');
        fa.classList.add(element.icon);
        if(e == 0){
            a.classList.add('active');
        }
        a.attr.add('href', 'javascript:;');
        if(undefined !== element.text){
            sp.text(element.text);
        }
        a.event('click', function(el){
            ul.each(function(elm, i){
                elm.childs[0].classList.remove('active');
            });
            el.classList.add('active');
            if(undefined !== element.event){
                new element.event(tools.e, tools);
            }
        });
    });

    let tools = newElement(app, 'div');
    tools.classList.add('tools');
    tools.attr.add('contenteditable', true);
}

function getElement(name){
    return document.querySelector(name);
}