<?php
/*
	Created by Mahmmoud Kassem (2018) all right recerved.
	PHP v7.0.0 and more than.
	this file for enter system informations, for connection to database.
*/
class ConfigController
{

	/*
		DATABASE SETTINGS
	*/
	const host = 'localhost';
	const userhost = 'root';
	const passhost = '1993mahmmoud';
	const dbname = '';
	
	/*
		PHP MAILE SETTINGS
	*/
	const SMTPDebug = false; // SMTP::DEBUG_SERVER
	const Host = 'HOSTNAME';
	const Username = 'email';
	const Password = 'password';
	const Port = 587;

	public function connection()
	{
		$conn = @new \PDO('mysql:host='.self::host.';dbname='.self::dbname.';', self::userhost, self::passhost);
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$conn->exec("set names utf8");
		return $conn;
	}
	
	public function LoadProcedure($ProcedureName = null, $vars)
	{
		$modelpath = __DIR__;
		$qu =  file_get_contents($modelpath.'/procedures/'.$ProcedureName.'.sql');
		if($vars != null){
			foreach(array_keys($vars) as $key)
			{
				if(is_numeric($vars[$key]) || is_float($vars[$key])){
					if(null == $vars[$key]){
						$qu = str_replace($key, 0, $qu);
					}else{
						$qu = str_replace($key, $vars[$key], $qu);
					}
				}else if(is_string($vars[$key])){
					if(null == $vars[$key]){
						$qu = str_replace($key, 'null', $qu);
					}else{
						$qu = str_replace($key, "'".$vars[$key]."'", $qu);
					}
				}
			}
		}
		return $qu;
	}
}