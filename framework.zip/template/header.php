<!DOCTYPE html>
<html>
<head>
	<title>Mahmoud Qassem Framework v1.0.0</title>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<!-- CSS -->
	<link rel="stylesheet" href="template/css/main.css" >
	<!-- JS -->
	<script src="template/js/main.js"></script>
</head>
<body>