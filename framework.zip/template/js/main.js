window.onload = function(){
    let words = ['مرحبا', 'Hello' , '여보세요', 'Здраво', 'Hola', 'Ciao', '你好', 'नमस्ते', 'Slav', 'سلام', 'Olá', 'Merhaba'];
    let i = 0;
    setInterval(() => {
        if(i < words.length){
            document.querySelector('.swiper-slide span').innerHTML = words[i];
            document.querySelector('.swiper-slide span').classList.add('zoom');
            setTimeout(() => {
                document.querySelector('.swiper-slide span').classList.remove('zoom');
            }, 1100);
            i++;
        }else{
            i = 0;
            document.querySelector('.swiper-slide span').innerHTML = words[0];
        }
    }, 2000);
}